# -*- coding: utf-8 -*-

#Ce fichier python est le fichier principal de notre projet.
#Il crée les graphiques et l'animation, et il va lire d'autres fichiers C et python.

import math
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import csv
from matplotlib.colors import LightSource
from matplotlib import cm

#Lire le fichier "simulation.c" qui simule le déplacement de chaque goutte d'eau
print("Lecture du fichier simulant le parcours des gouttes d'eau")
import subprocess
#Si vous voulez lancer ce programme avec un ordinateur qui n'a pas windows, veuillez changer le "/a.exe" en "/a.out"
#Il faut également le changer à la fin de ce code, car nous refaisons la même chose
print("Si vous voulez lancer ce programme avec un ordinateur qui n'a pas windows, veuillez changer le /a.exe en /a.out dans le code")
subprocess.call(["gcc","simulation.c"])
subprocess.call("./a.exe")

#Pour l'affichage 3D de la zone considérée autour du lac des Dix :

#Lecture du fichier
print("Lecture du fichier contenant les altitudes")
terrain = np.genfromtxt('altitudes.csv', delimiter = ',', dtype = None)
#chaque case du tableau contient l'altitude correspondante

#Coordonnée x (latitudes)
coord_x_inv = []
for i in range(0, len(terrain[0, :])):
    coord_x_inv.append(i*200)
    #chaque case est en réalité espacée de 200m
coord_x = list(reversed(coord_x_inv))

#idem pour les coordonnées y (longitudes):
coord_y = []
for i in range(len(terrain[:, 0])):
    coord_y.append(i*200)

#Créer un tableau avec les coordonnées x de chaque case
x = np.zeros((len(coord_y), len(coord_x)))
for i in range(0, len(coord_y)):
    x[i, :]=coord_x

#Créer un tableau avec les coordonnées y de chaque case
y = np.zeros((len(coord_y), len(coord_x)))
for i in range(0, len(coord_x)):
    y[:, i]=coord_y

alt_min = np.min(terrain)
alt_max = np.max(terrain)
#Coordonnées de l'axe z (altitudes)
coord_z = np.linspace(alt_min, alt_max)
#donc les altitudes vont de alt_min à alt_max

#Pour afficher le terrain en 3D, nous utilisons la fonction plot_surface
#Graphique de la zone considérée
fig, ax = plt.subplots(subplot_kw=dict(projection='3d'))
ls = LightSource(270, 45)
rgb = ls.shade(terrain, cmap=cm.gist_earth, vert_exag=0.1, blend_mode='soft')
surf = ax.plot_surface(x, y, terrain, rstride=1, cstride=1, facecolors=rgb, linewidth=0, antialiased=False, shade=False)
plt.show()


#Pour l'animation du déplacement des gouttes d'eau:
print("Préparation de l'animation")
#Tableau contenant la position de chaque goutte toutes les 2 min
#Quand une goutte s'arrête, sa position est mise à 0
#Pour voir de quelle manière le tableau est créé, voir le fichier "simulation.c"
anim = np.genfromtxt('animation.csv', delimiter = ',', dtype = None)

#Remplacer les positions "0" par les dernières coordonnées de la goutte
for i in range(len(anim[0, :])):
    for k in range(len(anim[:, 0])):
        if anim[k, i]==0:
            anim[k, i]=anim[k-1, i]

#Tableau contenant les altitudes
altitudes = np.genfromtxt('altitudes.csv', delimiter = ',', dtype = None)
#Coordonnées x et y correspondantes
xp = 592800 + np.arange(0, 37)*200
yp = 103800 - np.arange(0, 44)*200

#Pour afficher un seul graphique à un temps choisi (temps qui est toutes les 2 min):
"""
minutes = 120
#Cet exemple nous montre les positions des gouttes après 120*2 = 240 minutes
#Coordonnées x
x = []
for i in range(0, len(anim[0, :]), 2):
    x.append(anim[minutes, i])

#Coordonnées y
y = []
for i in range(1, len(anim[0, :]), 2):
    y.append(anim[minutes, i])

plt.plot(x, y, '.', c='#fc0000')
plt.title("Positions des gouttes")
plt.xlabel("Latitudes")
plt.ylabel("Longitudes")
plt.pcolormesh(xp, yp, altitudes, shading = 'auto')
plt.show()
"""
#Création de l'animation avec FuncAnimation
fig = plt.figure()
ax = fig.add_subplot()

p = None

def init():
	pass

def animate(i):
    #print(i)

    global p
    if p != None:
    	p[0].remove()

    x = []
    for k in range(0, len(anim[0, :]), 2) :
        x.append(anim[i, k])
    y = []
    for j in range(1, len(anim[0, :]), 2):
        y.append(anim[i, j])
    p = ax.plot(x, y, '.', c='#fc0000')

altitudes = np.genfromtxt('altitudes.csv', delimiter = ',', dtype = None)
xp = 592800 + np.arange(0, 37)*200
yp = 103800 - np.arange(0, 44)*200

a = animation.FuncAnimation(fig, animate, init_func=init, frames=range(1257), interval=50, blit=False, repeat=False)
#Il y a 1257 graphes qui sont affichés à la suite
plt.title("Positions des gouttes d'eau")
plt.xlabel("Latitudes")
plt.ylabel("Longitudes")
plt.pcolormesh(xp, yp, altitudes, shading = 'auto')
plt.show()
#L'animation s'arrête dès que la dernière goutte entre dans le lac des Dix
#C'est pour ça que les gouttes se trouvant au Nord Ouest s'arrêtent brutalement à la fin de l'animation


#Création des graphes montrant à quel moment les quantités d'eau arrivent dans le lac des Dix
#Tableau contenant le temps que met chaque goutte d'eau (pour aller jusqu'au lac des Dix)
temps = np.genfromtxt('time.csv', delimiter = ',', dtype = None)
#Nous mettons ces temps dans une liste :
list1=[]
for i in range(931):
    list1.append(temps[i])
#Puis nous la trions :
list2 = sorted(list1)

#Création d'une liste contenant le nombre de gouttes arrivant dans le lac toutes les 600 secondes (= 10 min)
#il y a 252 intervalles
#Au total, 931 gouttes vont dans le lac (donc 931 cases mènent au lac)
list3=[]
for i in range(252):  
    list3.append(0)
k=0
t=600
p=0
i=0
while t<151800 and i<931:
    if k<=list2[i] and list2[i]<t:
        list3[p]+=1     
        i+=1
    elif list2[i]>=t:
        k += 600
        t += 600
        p += 1

#Liste contenant les valeurs du temps en heures (pour ensuite créer l'axe "temps" dans le graphe)
list4=[]
for i in range(252):
    list4.append(i*600/3600)
plt.bar(list4,list3)
plt.title("Catchment avec les rivières, Lac des Dix")
plt.xlabel("Temps en heure (intervalle de 600 s)")
plt.ylabel("Nombre de gouttes")
plt.show()

#Liste contenant la quantité de gouttes absorbées dans le sol
list5=[]
#Ici, le modèle choisit est "absorption = la racine carrée de la quanttité d'eau tombée"
#Le choix est fait de cette manière, car (comme nous pouvons le voir sur le graphique)
#si beaucoup de goutte tombent rapidement, le sol est vite saturé et beaucoup de gouttes ruissellent
#et si peu de gouttes tombent, alors il y a une grande partie qui est abrosbée dans le sol
#Au début, nous voulions utiliser un vrai modèle physique, mais cela devient vite compliqué
#et nous ne connaissons pas toutes les constantes liées à notre terrain, etc.

for i in range(252):
    t=math.sqrt(list3[i])
    list5.append(t)

#Liste contenant le ruissellement
list6=[]
for i in range(252):
    p=list3[i]-list5[i]
    list6.append(p)
#Pour le graphe, nous choisissons une largeur des barres égale à 1
width = 1

fig, ax = plt.subplots()

ax.bar(list4, list6, width, label='Ruissellement')
ax.bar(list4, list5, width, label='Absorption')
ax.set_ylabel('Nombre de gouttes')
ax.set_xlabel('Temps [h]')
ax.set_title('Absorption model')
ax.legend()
plt.show()


#Faire le graphe de la quantité d'eau qui arrive dans le lac
#en fonction des précipitations, fichier json provenant d'internet (Meteoblue)
from jsonreader1 import json_reader

#Nous faisons la même choses que pour le graphique précédent
#Mais cette fois, nous considérons le nombre de gouttes qui arrivent dans le lac chaque heure (=3600 secondes)
#Il y a donc 42 intervalles
nbr_gouttes=[]
for i in range(42):  
    nbr_gouttes.append(0)
k=0
t=3600
p=0
i=0
#Si le temps est compris dans l' intervalle de 3600 secondes, on ajoute 1 à l'indice correspondant
while t<151800 and i<931:
    if k<=list2[i] and list2[i]<t:
        nbr_gouttes[p]+=1     
        i+=1
    elif list2[i]>=t:
        k += 3600
        t += 3600
        p += 1

#Dans nbr_gouttes, nous avons le nombre de gouttes qu'il y a toutes les heures (=3600 sec)
#Liste avec les heures :
heures=[]
for i in range(len(nbr_gouttes)):
    heures.append(i)

#Récupérer les précipitations venant du fichier json venant d'internet (Meteoblue)
print("Nous pouvons récupérer les données des précipitations durant 182 heures au maximum.")
duree_p = input("Sur quelle durée (en heures) voulez-vous récupérer les données des précipitations ? \nVeuillez entrer un nombre entier entre 0 et 182 : ")

#Si l'input n'est pas un nombre entier, nous choisissons une valeur pour pouvoir continuer
if not duree_p.isnumeric():
    print("Vous n'avez pas choisi un nombre entier entre 0 et 182...")
    print("Nous choisissons donc une valeur à votre place : 30 heures.")
    duree_precip = 30
elif int(duree_p)<0 or int(duree_p)>182:
    print("Vous n'avez pas choisi un nombre entier entre 0 et 182...")
    print("Nous choisissons donc une valeur à votre place : 30 heures.")
    duree_precip = 30
else :
    duree_precip = int(duree_p)

#Récupérer les données des précipitations
precipitations = json_reader("precipitation1.json")
#Dans le fichier "quantite_precipitation1.json", nous récupérons les données des précipitations actuelles
#Hors, celles-ci sont parfois toutes égales à 0 (s'il ne pleut pas)
#C'est pour cela que nous prenons les données de "precipitation1.json" qui datent  du 11.11.2021 (00:00) au 18.11.2021 (13:00)
#Celles-ci ne sont pas toutes égales à 0

pluie = []
for i in range(duree_precip):
    pluie.append(precipitations[i])

"""
#Si nous voulons faire le graphe avec des précipitations de 1mm chaque heure :
pluie = []
for i in range(duree_precip):
    pluie.append(1)
"""

#Calcul du volume d'eau arrivant dans le lac
#Il y a un déphasage entre le moment où les précipitations tombent et le moment où l'eau arrive dans le lac
#Pour cela, nous utilisons le principe de convolution
n = len(pluie)
m = len(nbr_gouttes)

#Tableau contenant le volume d'eau arrivant dans le lac, en fonction du temps
resultat = np.zeros((1,n+m))

#Nous le remplissons avec le volume d'eau tombé :
#Pour cela, nous utilisons le résultat du graphique nous indiquant à quel moment les gouttes d'eau arrive dans le lac ("nbr_gouttes")

for i in range(n):
    IUHdecale = np.zeros((1,n+m))
    #Nous faisons le déphasage selon à quel moment les précipitations ont lieu
    IUHdecale[0, i:m+i] = nbr_gouttes[0:m]
    #Nous multiplions les valeur par le volume d'eau tombé
    IUHdecale = IUHdecale*(pluie[i]/1000)*200*200
    #la pluie (en mm) tombe dans des cases de 200 mètres carrés
    #et nous additionnons les volumes d'eau (en fonction du temps) pour avoir le volume total arrivant au lac, en fonction du temps
    resultat = resultat + IUHdecale

#Liste contenant le temps correspondant à "resultat"
t = []
for i in range(len(resultat[0, :])):
    t.append(i)

#Liste contenant le temps correspondant à "pluie"
t2 = []
for i in range(len(pluie)):
    t2.append(i)

#Liste contenant le volume total de pluie tombé en fonction du temps
#La pluie (en mm) tombe dans des cases de 200 mètres carrés
#et 931 cases mènent au lac des Dix
pluie2 = []
for i in range(len(pluie)):
    pluie2.append((pluie[i]/1000)*200*200*931)

#Création du graphique
fig, ax = plt.subplots()

ax.bar(t2, pluie2, width, label='Volume des précipitations')
ax.bar(t, list(resultat[0, :]), width, alpha=0.75, label='Volume d\'eau arrivant dans le lac')

ax.set_ylabel('Volume d\'eau [mètres cubes]')
ax.set_xlabel('Temps [h]')
ax.set_title('Catchment, lac des Dix')
ax.legend()
plt.show()

#Pour vérifier que le résultat soir correct :
#print(sum(pluie2))
#print(sum(list(resultat[0, :])))
#Il y a bien la même quantité d'eau qui tombe sur le terrain (dans les 931 cases) et qui arrive dans le lac

#Surface du lac des Dix = 3.65 km^2
surface = 3650000

#Après la durées choisie par l'utilisateur, le volume d'eau qui arrive dans le lac est de :
volume = sum(list(resultat[0, :]))
hauteur = volume/surface
print(f"Une fois toute l'eau arrivée dans le lac, la hauteur du lac des Dix aura augmenté de {hauteur} m.")

#Lecture du fichier "productionE.c" calculant l'énergie produite par la centrale de Bieudron en fonction de deux débits différents
subprocess.call(["gcc","productionE.c"])
subprocess.call("./a.exe")

#Nous avons aussi rendu un fichier calculant le parcours des gouttes jusqu'au lac de la même façon qu'au Midterm ("goutteSimplifiee.c")
#(nous n'exécutons pas ce fichier ici)

#Nous pouvons donc comparer les "catchment" des deux  manières de faire :
#Avec la méthode du Midterm et en supposant le lac rectangulaire, 652 cases mènent au lac (cf. "eau.csv" créé depuis le fichier "goutteSimplifiee.c")
#Avec notre méthode (et en modélisant le lac de manière plus réaliste), 931 cases mènent au lac des Dix (cf "catchment.csv")
#Dans ces csv, les "1" correspondent aux cases menant au lac

#Il n'y a cependant pas le même nombre de cases dans les deux cas :
#avec la méthode du Midterm : 1 case = 1 altitude
#avec notre méthode : les 4 angles d'une case sont des altitudes, il y a donc moins de cases

#Finalement, dans "rivieres.csv", nous pouvons voir l'emplacement des rivières (cases contenant un "1")
