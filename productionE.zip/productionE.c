#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <math.h>

//Ce fichier calcule l'énergie électrique produite par la centrale de Bieudron pour deux débits différents

//Le modèle utilisé est normalement adapté pour des petits barrages
//Cependant, le barrage de la Grande Dixence est grand
//ceci explique en partie pourquoi le résultat obtenu est assez loin de la réalité
//De plus, nous ne prenons pas en compte les moments où la centrale ne fonctionne pas

//Nous avons trouvé ce modèle et les données dans trois document différents : 
//"Cleuson-Dixence" provenant de Alpiq et de la Grande Dixence
//"70e rapport Exercice 2020" de la Grande Dixence
//"Guide pour l'étude sommaire de petites centrales hydrauliques" (Michel Dubas et Yves Pigueron)

//Avec les pertes, pauses pour cause de chute du réseaux hydrolique, etc, on peut admettre
//un rendement total moyen relativement pessimiste de 70% et le supposer constant

//Struct contenant des information sur la centrale de Bieudron
struct Centrale {
	double diametre;
	double Dh;
	double chutte_brutte;
	double longueur;
	double rugosite;
	double rendement_tot;
};

//Fonction mesurant la perte en charge (énergie perdue)
double perte_en_charge(struct Centrale * bieudron, double temperature, double debit){
	//Pour une température entre 0 et 30 degré, la viscosité se calcule comme suit:
	double viscosite_cinematique = (1.78*pow(10,-6))/(1 + (0.0337*temperature) + (0.000221*pow(temperature,2)));
	double Re = (debit/(bieudron->diametre*M_PI))*bieudron->Dh/viscosite_cinematique;
	//étant donné que la formule de Colebrook est très compliquée, nous utilisons la formule "Swamee-Jain equation"
	//assume full-flowing circular pipe (cf page wikipedia "Darcy friction factor formulae")
	double temp = log10(((bieudron->rugosite/bieudron->Dh)/3.7) + (5.74/pow(Re,0.9)));
	double coeff_perte = 0.25/pow(temp,2);
	double dHr = coeff_perte*(bieudron->longueur/pow(bieudron->Dh,5))*((8*pow(debit,2))/(pow(M_PI,2)*9.81));
	return dHr;
}

//énergie électrique produite par jour:
double production_E(struct Centrale * bieudron, double debit, double temperature){
	double rho_eau = 999.87 + 0.0655*temperature - 8.46875*pow(10,-3)*pow(temperature,2) + 5.46875*pow(10,-5)+pow(temperature,2);
	
	double chutte_nette = bieudron->chutte_brutte - perte_en_charge(bieudron, temperature, debit);
	//Puissance hydraulique :
	double P_hydr = rho_eau*debit*9.81*chutte_nette;
	//Puissance électrique :
	double P_electrique = bieudron->rendement_tot*P_hydr;
	//énergie électrique produite durant 1 an
	double E_produite = P_electrique*24*365*pow(10, -9);//*10^-9 pour mettre en GWh
	
	return E_produite;
}

int main(int argc, char * argv[]) {
	//On suppose que l'eau remplit tout le tuyau et que ce tuyau a un diamètre intérieur constant
	
	//initialiser la structure
	struct Centrale bieudron;
	bieudron.diametre = 4.2;
	bieudron.Dh = pow(((bieudron.diametre)/2),2)*M_PI*4/(M_PI*(bieudron.diametre));
	bieudron.chutte_brutte = 1883;
	bieudron.longueur = 4230;
	bieudron.rugosite = 0.4;
	bieudron.rendement_tot = 0.7;
	//info pour le calcul : debit max = 75 m^3 /s ; Dh = 4.2 ; viscosité = 0.00000101 => Re = 2.3*10^7
	
	double debit1 = 75;
	//exemple de température:
	double temperature = 10;//Température moyenne durant une année à la Grande Dixence

	double debit2 = 55;
	double E1 = production_E(&bieudron, debit1, temperature);
	double E2 = production_E(&bieudron, debit2, temperature);
	
	printf("Si le debit (maximum) est de %f m^3/s\n", debit1);
	printf("L'usine de Bieudron produit au maximum %f GWh par annee.\n", E1);
	
	printf("Si le debit est de %f m^3/s (debit moyen)\n", debit2);
	printf("L'usine de Bieudron produit %f GWh par annee.\n", E2);
	return 0;
}
//il y a trop d'énergie qui est produite comparé à la réalité
//Production annuelle moyenne de la centrale de bieudron = 2000 GWh/an
//Avec un débit de 55 m^3/s, on obtient 6559 GWh/an

//Etant donné que le résultat est loin de la réalité, nous n'allons pas calculer l'énergie produite avec le changement du niveau du lac que nous avons calculé
//Mais si nous voulions calculer l'énergie produite, nous aurions également ajouté le volume d'eau provenant de la fonte des glaciers
//(il y a des chiffres dans les pdf que nous avons lu)
